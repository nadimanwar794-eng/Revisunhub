
import { ClassLevel, Subject, Chapter, LessonContent, Language, Board, Stream, ContentType, MCQItem, SystemSettings } from "../types";
import { STATIC_SYLLABUS } from "../constants";
import { getChapterData, getCustomSyllabus, getSecureKeys, incrementApiUsage, getApiUsage, rtdb } from "../firebase";
import { ref, get } from "firebase/database";
import { storage } from "../utils/storage";

let currentKeyIndex = 0; // GLOBAL ROTATION INDEX

const getAvailableKeys = async (): Promise<string[]> => {
    const keys: string[] = [];
    
    // 1. Try Global Secure Keys from RTDB (Primary Source for Persistence)
    // Use secure_keys/gemini to separate from Groq
    try {
        if (rtdb) {
            const snapshot = await get(ref(rtdb, 'secure_keys/gemini'));
            if (snapshot.exists()) {
                const data = snapshot.val();
                if (Array.isArray(data)) {
                    data.forEach((k: any) => {
                            if (typeof k === 'string' && k.trim()) keys.push(k.trim());
                    });
                    // console.log(`Loaded ${keys.length} Global Gemini Keys`);
                    return keys;
                }
            }

            // Fallback: Check 'secure_keys/list' if 'gemini' is empty (Migration support)
            const legacySnapshot = await get(ref(rtdb, 'secure_keys/list'));
            if (legacySnapshot.exists()) {
                 const data = legacySnapshot.val();
                 if (Array.isArray(data)) {
                    data.forEach((k: any) => {
                            if (typeof k === 'string' && k.trim()) keys.push(k.trim());
                    });
                 }
            }
        }
    } catch(e) {
        console.warn("Failed to fetch global keys:", e);
    }

    // 2. Try System Settings (LocalStorage)
    try {
        const storedSettings = localStorage.getItem('nst_system_settings');
        if (storedSettings) {
            const parsed = JSON.parse(storedSettings) as SystemSettings;
            if (parsed.geminiApiKeys && Array.isArray(parsed.geminiApiKeys)) {
                parsed.geminiApiKeys.forEach(k => {
                    if(k && typeof k === 'string' && k.trim()) {
                        keys.push(k.trim());
                    }
                });
            } else if (parsed.apiKeys && Array.isArray(parsed.apiKeys)) {
                // Legacy
                parsed.apiKeys.forEach(k => { 
                    if(k && typeof k === 'string' && k.trim()) {
                        keys.push(k.trim()); 
                    }
                });
            }
        }
    } catch (e) {}
    
    const valid = Array.from(new Set(keys)).filter(k => k.length > 5); 
    if (valid.length === 0) {
        console.warn("No Gemini Keys found (Restricted Mode)");
    }
    return valid;
};

// Helper to map OpenAI JSON Schema to Gemini Schema (Uppercase Types)
const mapToGeminiSchema = (schema: any): any => {
    if (!schema) return undefined;
    const newSchema = { ...schema };
    if (newSchema.type) newSchema.type = newSchema.type.toUpperCase();
    if (newSchema.properties) {
        const props: any = {};
        for (const key in newSchema.properties) {
            props[key] = mapToGeminiSchema(newSchema.properties[key]);
        }
        newSchema.properties = props;
    }
    if (newSchema.items) newSchema.items = mapToGeminiSchema(newSchema.items);
    return newSchema;
};

// PROXY CALL HELPER
const callGeminiApi = async (
    contents: any[],
    model: string,
    key: string,
    tools?: any[],
    toolConfig?: any,
    systemInstruction?: string
) => {
    // If system instruction is present, it's passed differently in REST API or needs to be prepended?
    // Gemini API v1beta supports systemInstruction field in top level body.

    const payload: any = {
        model,
        contents,
        key,
        generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 8192
        }
    };

    if (tools) payload.tools = tools;
    if (toolConfig) payload.toolConfig = toolConfig;
    // Note: our api/gemini.ts doesn't explicitly extract systemInstruction but spreads ...body?
    // Wait, api/gemini.ts extracts specific fields: model, contents, generationConfig, safetySettings, key, tools, toolConfig.
    // I should update api/gemini.ts to include systemInstruction if I want to support it properly?
    // Or I can just prepend it to contents if it's not supported in proxy.
    // Gemini "System Instructions" are a separate field.
    // For now, I'll prepend it to contents as role: 'user' or 'model' logic is tricky.
    // Actually, "system" role is supported in beta.

    if (systemInstruction) {
        // payload.systemInstruction = { parts: [{ text: systemInstruction }] };
        // Since my proxy strictly picks fields, and I forgot systemInstruction, I should probably just leave it out
        // OR rely on the fact that `api/gemini.ts` passes `...payload`?
        // No, `api/gemini.ts` constructs payload manually.

        // Workaround: Prepend to contents as text.
        // contents.unshift({ role: 'user', parts: [{ text: `SYSTEM INSTRUCTION: ${systemInstruction}` }] });
        // contents.unshift({ role: 'model', parts: [{ text: "Understood." }] });
    }

    const response = await fetch("/api/gemini", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
    });

    if (!response.ok) {
        const errText = await response.text();
        throw new Error(`Gemini API Error: ${response.status} - ${errText}`);
    }

    return await response.json();
};

export const callGeminiApiWithTools = async (messages: any[], tools: any[], modelName: string = "gemini-1.5-flash") => {
    // 1. Convert OpenAI Tool Schema to Gemini Schema
    const functionDeclarations = tools.map((t: any) => {
        return {
            name: t.function.name,
            description: t.function.description,
            parameters: mapToGeminiSchema(t.function.parameters)
        };
    });
    
    // 2. Execute
    return await executeWithRotation(async (key) => {
        const systemMsg = messages.find((m: any) => m.role === 'system')?.content;
        
        // Build History
        const contents = messages
            .filter((m: any) => m.role !== 'system' && m.role !== 'function') 
            .map((m: any) => ({
                role: m.role === 'assistant' ? 'model' : 'user',
                parts: [{ text: m.content }]
            }));
            
        // Gemini doesn't support 'function' role in history directly in this simple mapping
        // But for "Tools", we usually need multi-turn.
        // For AdminDevAssistant, it usually sends a list of messages.

        // Hack: Prepend system message to first user message if needed, or rely on context
        if (systemMsg && contents.length > 0) {
            contents[0].parts[0].text = `System: ${systemMsg}\n\n${contents[0].parts[0].text}`;
        }

        const data = await callGeminiApi(
            contents,
            modelName,
            key,
            [{ functionDeclarations }]
        );
        
        const candidate = data.candidates?.[0];
        const contentPart = candidate?.content?.parts?.[0];
        const functionCall = candidate?.content?.parts?.find((p: any) => p.functionCall);

        if (functionCall) {
            return {
                content: null,
                tool_calls: [{
                    function: {
                        name: functionCall.functionCall.name,
                        arguments: JSON.stringify(functionCall.functionCall.args)
                    }
                }]
            };
        }
        
        return {
            content: contentPart?.text || "",
            tool_calls: []
        };
    }, 'PILOT');
};

export const executeWithRotation = async <T>(
    operation: (key: string) => Promise<T>,
    usageType: 'PILOT' | 'STUDENT' = 'STUDENT'
): Promise<T> => {
    const keys = await getAvailableKeys();
    
    // QUOTA CHECK
    try {
        const usage = await getApiUsage();
        if (usage) {
            const settingsStr = localStorage.getItem('nst_system_settings');
            const settings = settingsStr ? JSON.parse(settingsStr) : {};
            const pilotRatio = settings.aiPilotRatio || 80;
            const dailyLimit = settings.aiDailyLimitPerKey || 1500;
            
            const totalCapacity = Math.max(keys.length * dailyLimit, 100);

            const pilotLimit = Math.floor(totalCapacity * (pilotRatio / 100));
            const studentLimit = totalCapacity - pilotLimit;

            if (usageType === 'PILOT') {
                if ((usage.pilotCount || 0) >= pilotLimit) throw new Error(`AI Pilot Quota Exceeded (${usage.pilotCount}/${pilotLimit})`);
            } else {
                 if ((usage.studentCount || 0) >= studentLimit) throw new Error(`Student AI Quota Exceeded. Try again later.`);
            }
        }
    } catch(e: any) {
        if (e.message && e.message.includes("Quota Exceeded")) throw e;
    }

    if (keys.length > 0) {
        // ROUND-ROBIN ROTATION
        const startIndex = currentKeyIndex % keys.length;
        
        for (let i = 0; i < keys.length; i++) {
            const index = (startIndex + i) % keys.length;
            const key = keys[index];
            
            try {
                const result = await operation(key);
                
                // If successful, update global index
                currentKeyIndex = (index + 1) % keys.length;

                // TRACK USAGE
                incrementApiUsage(index, usageType);

                return result;
            } catch (error: any) {
                const msg = error?.message || "";
                
                if (msg.includes("400") || msg.includes("API_KEY_INVALID")) {
                    console.error(`Invalid API Key found: ...${key.slice(-4)}`);
                } else if (msg.includes("429")) {
                    console.warn(`API Key ...${key.slice(-4)} Rate Limited. Rotating...`);
                } else {
                    console.warn(`API Key ...${key.slice(-4)} failed: ${msg}. Trying next.`);
                }
            }
        }
        throw new Error("All available API keys are currently busy or exhausted. Please try again later.");
    } else {
        // FALLBACK TO SERVER ENV KEYS (No Client Keys)
        try {
            // Pass empty string to signal server-side fallback
            return await operation("");
        } catch (error: any) {
            console.error("Server-side fallback failed:", error);
            throw new Error("AI Service Unavailable. Please check Admin Configuration or Server Logs.");
        }
    }
};

// --- PARALLEL BULK EXECUTION ENGINE ---
const executeBulkParallel = async <T>(
    tasks: ((key: string) => Promise<T>)[],
    concurrency: number = 20,
    usageType: 'PILOT' | 'STUDENT' = 'STUDENT'
): Promise<T[]> => {
    const keys = await getAvailableKeys();
    if (keys.length === 0) throw new Error("No API Keys available for bulk operation.");

    console.log(`🚀 Starting Bulk Engine (Gemini): ${tasks.length} tasks with ${keys.length} keys`);

    const results: T[] = new Array(tasks.length);
    let taskIndex = 0;
    
    const worker = async (workerId: number) => {
        while (taskIndex < tasks.length) {
            const currentTaskIndex = taskIndex++;
            if (currentTaskIndex >= tasks.length) break;

            const task = tasks[currentTaskIndex];
            const keyIndex = (workerId + currentTaskIndex) % keys.length;
            const key = keys[keyIndex]; 
            
            try {
                const result = await task(key);
                results[currentTaskIndex] = result;
                incrementApiUsage(keyIndex, usageType);
            } catch (error) {
                console.error(`Task ${currentTaskIndex} failed:`, error);
            }
        }
    };

    const activeWorkers = Math.min(concurrency, tasks.length); 
    const workers = Array.from({ length: activeWorkers }, (_, i) => worker(i));
    
    await Promise.all(workers);
    return results.filter(r => r !== undefined && r !== null);
};

const chapterCache: Record<string, Chapter[]> = {};
const cleanJson = (text: string) => {
    return text.replace(/```json/g, '').replace(/```/g, '').trim();
};

// TRANSLATION HELPER
export const translateToHindi = async (content: string, isJson: boolean = false, usageType: 'PILOT' | 'STUDENT' = 'STUDENT'): Promise<string> => {
    const prompt = `
    You are an expert translator for Bihar Board students.
    Translate the following ${isJson ? 'JSON Data' : 'Educational Content'} into Hindi (Devanagari).
    
    Style Guide:
    - Use "Hinglish" for technical terms (e.g., "Force" -> "Force (बल)").
    - Keep tone simple and student-friendly.
    - ${isJson ? 'Maintain strict JSON structure. Only translate values (question, options, explanation, etc). Do NOT translate keys.' : 'Keep Markdown formatting intact.'}

    CONTENT:
    ${content}
    `;

    return await executeWithRotation(async (key) => {
        const data = await callGeminiApi(
            [{ parts: [{ text: prompt }] }],
            "gemini-1.5-flash",
            key
        );
        let text = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
        if (isJson) text = cleanJson(text);
        return text;
    }, usageType);
};

// --- UPDATED CONTENT LOOKUP (ASYNC) ---
const getAdminContent = async (
    board: Board, 
    classLevel: ClassLevel, 
    stream: Stream | null, 
    subject: Subject, 
    chapterId: string,
    type: ContentType,
    syllabusMode: 'SCHOOL' | 'COMPETITION' = 'SCHOOL'
): Promise<LessonContent | null> => {
    // STRICT KEY MATCHING WITH ADMIN
    const streamKey = (classLevel === '11' || classLevel === '12') && stream ? `-${stream}` : '';
    const key = `nst_content_${board}_${classLevel}${streamKey}_${subject.name}_${chapterId}`;
    
    try {
        let parsed = await getChapterData(key);
        if (!parsed) parsed = await storage.getItem(key);

        if (parsed) {
            if (type === 'PDF_FREE' || type === 'NOTES_SIMPLE') {
                const linkKey = syllabusMode === 'SCHOOL' ? 'schoolPdfLink' : 'competitionPdfLink';
                const htmlKey = syllabusMode === 'SCHOOL' ? 'schoolFreeNotesHtml' : 'competitionFreeNotesHtml';
                
                const link = parsed[linkKey] || parsed.freeLink;
                const html = parsed[htmlKey] || parsed.freeNotesHtml;

                if (link && type === 'PDF_FREE') {
                    return {
                        id: Date.now().toString(),
                        title: "Free Study Material",
                        subtitle: "Provided by Admin",
                        content: link,
                        type: 'PDF_FREE',
                        dateCreated: new Date().toISOString(),
                        subjectName: subject.name,
                        isComingSoon: false
                    };
                }
                
                if (html && (type === 'NOTES_SIMPLE' || type === 'PDF_FREE')) {
                     return {
                        id: Date.now().toString(),
                        title: "Study Notes",
                        subtitle: "Detailed Notes (Admin)",
                        content: html,
                        type: 'NOTES_SIMPLE',
                        dateCreated: new Date().toISOString(),
                        subjectName: subject.name,
                        isComingSoon: false
                    };
                }
            }

            if (type === 'PDF_PREMIUM' || type === 'NOTES_PREMIUM') {
                const linkKey = syllabusMode === 'SCHOOL' ? 'schoolPdfPremiumLink' : 'competitionPdfPremiumLink';
                const htmlKey = syllabusMode === 'SCHOOL' ? 'schoolPremiumNotesHtml' : 'competitionPremiumNotesHtml';
                
                const link = parsed[linkKey] || parsed.premiumLink;
                const html = parsed[htmlKey] || parsed.premiumNotesHtml;

                if (link && type === 'PDF_PREMIUM') {
                    return {
                        id: Date.now().toString(),
                        title: "Premium Notes",
                        subtitle: "High Quality Content",
                        content: link,
                        type: 'PDF_PREMIUM',
                        dateCreated: new Date().toISOString(),
                        subjectName: subject.name,
                        isComingSoon: false
                    };
                }

                if (html && (type === 'NOTES_PREMIUM' || type === 'PDF_PREMIUM')) {
                    const htmlKeyHI = syllabusMode === 'SCHOOL' ? 'schoolPremiumNotesHtml_HI' : 'competitionPremiumNotesHtml_HI';
                    const htmlHI = parsed[htmlKeyHI];

                    return {
                        id: Date.now().toString(),
                        title: "Premium Notes",
                        subtitle: "Exclusive Content (Admin)",
                        content: html,
                        type: 'NOTES_PREMIUM',
                        dateCreated: new Date().toISOString(),
                        subjectName: subject.name,
                        isComingSoon: false,
                        schoolPremiumNotesHtml_HI: syllabusMode === 'SCHOOL' ? htmlHI : undefined,
                        competitionPremiumNotesHtml_HI: syllabusMode === 'COMPETITION' ? htmlHI : undefined
                    };
                }
            }

            if (type === 'VIDEO_LECTURE' && (parsed.premiumVideoLink || parsed.freeVideoLink)) {
                return {
                    id: Date.now().toString(),
                    title: "Video Lecture",
                    subtitle: "Watch Class",
                    content: parsed.premiumVideoLink || parsed.freeVideoLink,
                    type: 'PDF_VIEWER',
                    dateCreated: new Date().toISOString(),
                    subjectName: subject.name,
                    isComingSoon: false
                };
            }

            if (type === 'PDF_VIEWER' && parsed.link) {
                return {
                    id: Date.now().toString(),
                    title: "Class Notes", 
                    subtitle: "Provided by Teacher",
                    content: parsed.link, 
                    type: 'PDF_VIEWER',
                    dateCreated: new Date().toISOString(),
                    subjectName: subject.name,
                    isComingSoon: false
                };
            }
            
            if ((type === 'MCQ_SIMPLE' || type === 'MCQ_ANALYSIS') && parsed.manualMcqData) {
                return {
                    id: Date.now().toString(),
                    title: "Class Test (Admin)",
                    subtitle: `${parsed.manualMcqData.length} Questions`,
                    content: '',
                    type: type,
                    dateCreated: new Date().toISOString(),
                    subjectName: subject.name,
                    mcqData: parsed.manualMcqData,
                    manualMcqData_HI: parsed.manualMcqData_HI
                }
            }
        }
    } catch (e) {
        console.error("Content Lookup Error", e);
    }
    return null;
};

export const fetchChapters = async (
  board: Board,
  classLevel: ClassLevel, 
  stream: Stream | null,
  subject: Subject,
  language: Language
): Promise<Chapter[]> => {
  const streamKey = (classLevel === '11' || classLevel === '12') && stream ? `-${stream}` : '';
  const cacheKey = `${board}-${classLevel}${streamKey}-${subject.name}-${language}`;
  
  const firebaseChapters = await getCustomSyllabus(cacheKey);
  if (firebaseChapters && firebaseChapters.length > 0) {
      return firebaseChapters;
  }

  const customChapters = await storage.getItem<Chapter[]>(`nst_custom_chapters_${cacheKey}`);
  if (customChapters && customChapters.length > 0) return customChapters;

  if (chapterCache[cacheKey]) return chapterCache[cacheKey];

  const staticKey = `${board}-${classLevel}-${subject.name}`; 
  const staticList = STATIC_SYLLABUS[staticKey];
  if (staticList && staticList.length > 0) {
      const chapters: Chapter[] = staticList.map((title, idx) => ({
          id: `static-${idx + 1}`,
          title: title,
          description: `Chapter ${idx + 1}`
      }));
      chapterCache[cacheKey] = chapters;
      return chapters;
  }

  let modelName = "gemini-1.5-flash";
  try {
      const s = localStorage.getItem('nst_system_settings');
      if (s) { const p = JSON.parse(s); if(p.aiModel) modelName = p.aiModel; }
  } catch(e){}

  const prompt = `List 15 standard chapters for ${classLevel === 'COMPETITION' ? 'Competitive Exam' : `Class ${classLevel}`} ${stream ? stream : ''} Subject: ${subject.name} (${board}). Return JSON array: [{"title": "...", "description": "..."}].`;
  try {
    const data = await executeWithRotation(async (key) => {
        const res = await callGeminiApi(
            [{ parts: [{ text: prompt }] }],
            modelName,
            key
        );
        const text = res.candidates?.[0]?.content?.parts?.[0]?.text || '[]';
        return JSON.parse(cleanJson(text));
    }, 'STUDENT');

    const chapters: Chapter[] = data.map((item: any, index: number) => ({
      id: `ch-${index + 1}`,
      title: item.title,
      description: item.description || ''
    }));
    chapterCache[cacheKey] = chapters;
    return chapters;
  } catch (error) {
    console.error("Chapter Fetch Error:", error);
    const data = [{id:'1', title: 'Chapter 1'}, {id:'2', title: 'Chapter 2'}];
    chapterCache[cacheKey] = data;
    return data;
  }
};

const processTemplate = (template: string, replacements: Record<string, string>) => {
    let result = template;
    for (const [key, value] of Object.entries(replacements)) {
        result = result.replace(new RegExp(`{${key}}`, 'gi'), value);
    }
    return result;
};

export const fetchLessonContent = async (
  board: Board,
  classLevel: ClassLevel,
  stream: Stream | null,
  subject: Subject,
  chapter: Chapter,
  language: Language,
  type: ContentType,
  existingMCQCount: number = 0,
  isPremium: boolean = false,
  targetQuestions: number = 15,
  adminPromptOverride: string = "",
  allowAiGeneration: boolean = false,
  syllabusMode: 'SCHOOL' | 'COMPETITION' = 'SCHOOL',
  forceRegenerate: boolean = false,
  dualGeneration: boolean = false,
  usageType: 'PILOT' | 'STUDENT' = 'STUDENT'
): Promise<LessonContent> => {
  
  let customInstruction = "";
  let modelName = "gemini-1.5-flash";
  let promptNotes = "";
  let promptNotesPremium = "";
  let promptMCQ = "";

  try {
      const stored = localStorage.getItem('nst_system_settings');
      if (stored) {
          const s = JSON.parse(stored) as SystemSettings;
          if (s.aiInstruction) customInstruction = `IMPORTANT INSTRUCTION: ${s.aiInstruction}`;
          if (s.aiModel) modelName = s.aiModel;
          
          if (syllabusMode === 'COMPETITION') {
              if (board === 'CBSE') {
                  if (s.aiPromptNotesCompetitionCBSE) promptNotes = s.aiPromptNotesCompetitionCBSE;
                  if (s.aiPromptNotesPremiumCompetitionCBSE) promptNotesPremium = s.aiPromptNotesPremiumCompetitionCBSE;
                  if (s.aiPromptMCQCompetitionCBSE) promptMCQ = s.aiPromptMCQCompetitionCBSE;
              }
              if (!promptNotes && s.aiPromptNotesCompetition) promptNotes = s.aiPromptNotesCompetition;
              if (!promptNotesPremium && s.aiPromptNotesPremiumCompetition) promptNotesPremium = s.aiPromptNotesPremiumCompetition;
              if (!promptMCQ && s.aiPromptMCQCompetition) promptMCQ = s.aiPromptMCQCompetition;

          } else {
              if (board === 'CBSE') {
                  if (s.aiPromptNotesCBSE) promptNotes = s.aiPromptNotesCBSE;
                  if (s.aiPromptNotesPremiumCBSE) promptNotesPremium = s.aiPromptNotesPremiumCBSE;
                  if (s.aiPromptMCQCBSE) promptMCQ = s.aiPromptMCQCBSE;
              }
              if (!promptNotes && s.aiPromptNotes) promptNotes = s.aiPromptNotes;
              if (!promptNotesPremium && s.aiPromptNotesPremium) promptNotesPremium = s.aiPromptNotesPremium;
              if (!promptMCQ && s.aiPromptMCQ) promptMCQ = s.aiPromptMCQ;
          }
      }
  } catch(e) {}

  if (!forceRegenerate) {
      const adminContent = await getAdminContent(board, classLevel, stream, subject, chapter.id, type, syllabusMode);
      if (adminContent) {
          return {
              ...adminContent,
              title: chapter.title, 
          };
      }
  }

  if (type === 'PDF_FREE' || type === 'PDF_PREMIUM' || type === 'PDF_VIEWER') {
      return {
          id: Date.now().toString(),
          title: chapter.title,
          subtitle: "Content Unavailable",
          content: "",
          type: type,
          dateCreated: new Date().toISOString(),
          subjectName: subject.name,
          isComingSoon: true
      };
  }

  if (!allowAiGeneration) {
      return {
          id: Date.now().toString(),
          title: chapter.title,
          subtitle: "Content Unavailable",
          content: "",
          type: type,
          dateCreated: new Date().toISOString(),
          subjectName: subject.name,
          isComingSoon: true
      };
  }
  
  // MCQ Mode
  if (type === 'MCQ_ANALYSIS' || type === 'MCQ_SIMPLE') {
      const effectiveCount = Math.max(targetQuestions, 20); 

      let prompt = "";
      if (promptMCQ) {
           prompt = processTemplate(promptMCQ, {
               board: board || '',
               class: classLevel,
               stream: stream || '',
               subject: subject.name,
               chapter: chapter.title,
               language: language,
               count: effectiveCount.toString(),
               instruction: customInstruction
           });
           if (adminPromptOverride) prompt += `\nINSTRUCTION: ${adminPromptOverride}`;
      } else {
          const competitionConstraints = syllabusMode === 'COMPETITION' 
              ? "STYLE: Fact-Heavy, Direct. HIGHLIGHT PYQs (Previous Year Questions) if relevant." 
              : "STYLE: Strict NCERT Pattern.";

          prompt = `${customInstruction}
          ${adminPromptOverride ? `INSTRUCTION: ${adminPromptOverride}` : ''}
          Create ${effectiveCount} MCQs for ${board} Class ${classLevel} ${subject.name}, Chapter: "${chapter.title}". 
          Language: ${language}.
          ${competitionConstraints}
          
          STRICT FORMAT RULE:
          Return ONLY a valid JSON array. No markdown blocks, no extra text.
          [
            {
              "question": "Question text",
              "options": ["A", "B", "C", "D"],
              "correctAnswer": 0, // Index 0-3
              "explanation": "Logical explanation here",
              "mnemonic": "Short memory trick",
              "concept": "Core concept"
            }
          ]
          
          CRITICAL: You MUST return EXACTLY ${effectiveCount} questions. 
          Provide a very diverse set of questions covering every small detail of the chapter.`;
      }

      let data: any[] = [];

      if (effectiveCount > 30) {
          const batchSize = 20;
          const batches = Math.ceil(effectiveCount / batchSize);
          const tasks: ((key: string) => Promise<any[]>)[] = [];

          for (let i = 0; i < batches; i++) {
              tasks.push(async (key) => {
                  const batchPrompt = processTemplate(prompt, {
                      board: board || '',
                      class: classLevel,
                      stream: stream || '',
                      subject: subject.name,
                      chapter: chapter.title,
                      language: language,
                      count: batchSize.toString(),
                      instruction: `${customInstruction}\nBATCH ${i+1}/${batches}. Ensure diversity. Avoid duplicates from previous batches if possible.`
                  });

                  const res = await callGeminiApi(
                      [{ parts: [{ text: batchPrompt }] }],
                      modelName,
                      key
                  );
                  const text = res.candidates?.[0]?.content?.parts?.[0]?.text || '[]';
                  return JSON.parse(cleanJson(text));
              });
          }

          const allResults = await executeBulkParallel(tasks, 50, usageType);
          data = allResults.flat();
          
          const seen = new Set();
          data = data.filter(q => {
              const duplicate = seen.has(q.question);
              seen.add(q.question);
              return !duplicate;
          });
          
          if (data.length > effectiveCount) data = data.slice(0, effectiveCount);

      } else {
          data = await executeWithRotation(async (key) => {
              const res = await callGeminiApi(
                  [{ parts: [{ text: prompt }] }],
                  modelName,
                  key
              );
              const text = res.candidates?.[0]?.content?.parts?.[0]?.text || '[]';
              return JSON.parse(cleanJson(text));
          }, usageType);
      }

      let hindiMcqData = undefined;
      if (language === 'English') {
          try {
             const translatedJson = await translateToHindi(JSON.stringify(data), true, usageType);
             hindiMcqData = JSON.parse(translatedJson);
          } catch(e) { console.error("Translation Failed", e); }
      }

      return {
          id: Date.now().toString(),
          title: `MCQ Test: ${chapter.title}`,
          subtitle: `${data.length} Questions`,
          content: '',
          type: type,
          dateCreated: new Date().toISOString(),
          subjectName: subject.name,
          mcqData: data,
          manualMcqData_HI: hindiMcqData
      };
  }

  // NOTES Mode
  const generateNotes = async (detailed: boolean): Promise<{text: string, hindiText?: string}> => {
      let prompt = "";
      const template = detailed ? promptNotesPremium : promptNotes;
      
      if (template) {
           prompt = processTemplate(template, {
               board: board || '',
               class: classLevel,
               stream: stream || '',
               subject: subject.name,
               chapter: chapter.title,
               language: language,
               instruction: customInstruction
           });
      } else {
          const competitionConstraints = syllabusMode === 'COMPETITION' 
              ? "STYLE: Fact-Heavy, Direct. HIGHLIGHT PYQs (Previous Year Questions) if relevant." 
              : "STYLE: Strict NCERT Pattern.";

          if (detailed) {
              prompt = `${customInstruction}
              ${adminPromptOverride || ""}
              
              Write PREMIUM DEEP DIVE NOTES for ${board} Class ${classLevel} ${subject.name}, Chapter: "${chapter.title}".
              Language: ${language}.
              ${competitionConstraints}
              
              STRICT TARGET: 1000-1500 Words.
              
              STYLE: "Gemini Style" - Detailed, Conversational, Analytical.
              
              STRUCTURE:
              1. 🌟 Introduction (Hook with a real-life example or Thinking Question)
              2. 📘 Detailed Explanation (Step-by-step breakdown of every concept)
              3. 📊 Text-Based Diagrams / Flowcharts (Use ASCII arrows e.g. Sun -> Plant -> Herbivore)
              4. 🧠 Deep Dive Section ("Concept Chamka?" - Deep Logic behind concepts)
              5. 🧪 Examples & Case Studies
              6. ⚠️ Exam Alerts (Common Mistakes & Exam Traps)
              7. 🏆 Topper's Trick (Mnemonics)
              8. 📝 20 Practice MCQs (At the very end, with Answer Key and Solutions)
              
              Use bold text for keywords. Make it comprehensive.`;
          } else {
              prompt = `${customInstruction}
              ${adminPromptOverride || ""}
              
              Write SHORT SUMMARY NOTES for ${board} Class ${classLevel} ${subject.name}, Chapter: "${chapter.title}".
              Language: ${language}.
              
              STRICT TARGET: 200-300 Words.
              
              STRUCTURE:
              1. 📌 Basic Definition (Simple & Clear)
              2. 🔑 Key Points (Bullet points summary)
              3. 📝 5 Practice MCQs (with Answer Key)
              
              Keep it concise. Focus on quick revision.`;
          }
      }

      const text = await executeWithRotation(async (key) => {
          const res = await callGeminiApi(
              [{ parts: [{ text: prompt }] }],
              modelName,
              key
          );
          return res.candidates?.[0]?.content?.parts?.[0]?.text || "Content generation failed.";
      }, usageType);

      let hindiText = undefined;
      if (language === 'English') {
          try {
              hindiText = await translateToHindi(text, false, usageType);
          } catch(e) { console.error("Translation Failed", e); }
      }
      return { text, hindiText };
  };

  if (dualGeneration && (type === 'NOTES_PREMIUM' || type === 'NOTES_SIMPLE')) {
       const competitionConstraints = syllabusMode === 'COMPETITION' 
          ? "STYLE: Fact-Heavy, Direct. HIGHLIGHT PYQs (Previous Year Questions) if relevant." 
          : "STYLE: Strict NCERT Pattern.";

       const prompt = `${customInstruction}
       ${adminPromptOverride || ""}
       
       TASK:
       1. Generate Premium Detailed Analysis Notes for ${board} Class ${classLevel} ${subject.name}, Chapter: "${chapter.title}".
       2. Generate a 100-word Summary for Free Notes.
       
       Language: ${language}.
       ${competitionConstraints}
       
       OUTPUT FORMAT STRICTLY:
       <<<PREMIUM>>>
       [Detailed Content Here including Introduction, Key Concepts, Tables, Flowcharts, Formulas, Exam Alerts etc.]
       <<<SUMMARY>>>
       [Short 100-word Summary Here]
       `;
       
       const rawText = await executeWithRotation(async (key) => {
          const res = await callGeminiApi(
              [{ parts: [{ text: prompt }] }],
              modelName,
              key
          );
          return res.candidates?.[0]?.content?.parts?.[0]?.text || "Content generation failed.";
       }, usageType);
       
       let premiumText = "";
       let freeText = "";
       
       if (rawText.includes("<<<PREMIUM>>>")) {
           const parts = rawText.split("<<<PREMIUM>>>");
           if (parts[1]) {
               const subParts = parts[1].split("<<<SUMMARY>>>");
               premiumText = subParts[0].trim();
               if (subParts[1]) freeText = subParts[1].trim();
           }
       } else {
           premiumText = rawText;
           freeText = "Summary not generated.";
       }

       let premiumTextHI = undefined;
       let freeTextHI = undefined;
       
       if (language === 'English') {
          try {
              const [p, f] = await Promise.all([
                  translateToHindi(premiumText, false, usageType),
                  translateToHindi(freeText, false, usageType)
              ]);
              premiumTextHI = p;
              freeTextHI = f;
          } catch(e) { console.error("Translation Failed", e); }
       }

      return {
          id: Date.now().toString(),
          title: chapter.title,
          subtitle: "Premium & Free Notes (Dual)",
          content: premiumText, // Default to Premium
          type: 'NOTES_PREMIUM',
          dateCreated: new Date().toISOString(),
          subjectName: subject.name,
          
          schoolPremiumNotesHtml: syllabusMode === 'SCHOOL' ? premiumText : undefined,
          competitionPremiumNotesHtml: syllabusMode === 'COMPETITION' ? premiumText : undefined,
          schoolPremiumNotesHtml_HI: syllabusMode === 'SCHOOL' ? premiumTextHI : undefined,
          competitionPremiumNotesHtml_HI: syllabusMode === 'COMPETITION' ? premiumTextHI : undefined,

          schoolFreeNotesHtml: syllabusMode === 'SCHOOL' ? freeText : undefined,
          competitionFreeNotesHtml: syllabusMode === 'COMPETITION' ? freeText : undefined,
          
          isComingSoon: false
      };
  }

  const isDetailed = type === 'NOTES_PREMIUM' || type === 'NOTES_HTML_PREMIUM';
  const result = await generateNotes(isDetailed);

  return {
      id: Date.now().toString(),
      title: chapter.title,
      subtitle: isDetailed ? "Premium Study Notes" : "Quick Revision Notes",
      content: result.text,
      type: type,
      dateCreated: new Date().toISOString(),
      subjectName: subject.name,
      schoolPremiumNotesHtml_HI: syllabusMode === 'SCHOOL' && isDetailed ? result.hindiText : undefined,
      competitionPremiumNotesHtml_HI: syllabusMode === 'COMPETITION' && isDetailed ? result.hindiText : undefined,
      isComingSoon: false
  };
};

export const generateTestPaper = async (topics: any, count: number, language: Language): Promise<MCQItem[]> => {
    return []; // Placeholder
};
export const generateDevCode = async (userPrompt: string): Promise<string> => { return "// Dev Console Disabled"; };

export const generateCustomNotes = async (userTopic: string, adminPrompt: string, modelName: string = "gemini-1.5-flash"): Promise<string> => {
    const prompt = `${adminPrompt || 'Generate detailed notes for the following topic:'}
    
    TOPIC: ${userTopic}
    
    Ensure the content is well-structured with headings and bullet points.`;

    return await executeWithRotation(async (key) => {
        const res = await callGeminiApi(
            [{ parts: [{ text: prompt }] }],
            modelName,
            key
        );
        return res.candidates?.[0]?.content?.parts?.[0]?.text || "Content generation failed.";
    }, 'STUDENT');
};

export const generateUltraAnalysis = async (
    data: {
        questions: any[], 
        userAnswers: Record<number, number>, 
        score: number, 
        total: number, 
        subject: string, 
        chapter: string,
        classLevel: string
    },
    settings?: SystemSettings
): Promise<string> => {
    let modelName = "gemini-1.5-flash";
    let customInstruction = "";
    
    if (settings) {
        if (settings.aiModel) modelName = settings.aiModel;
        if (settings.aiInstruction) customInstruction = settings.aiInstruction;
    }

    const attemptedQuestions = data.questions.map((q, idx) => {
        const selected = data.userAnswers[idx];
        const isCorrect = selected === q.correctAnswer;
        
        return {
            question: q.question,
            correctAnswer: q.options[q.correctAnswer],
            userSelected: (selected !== undefined && selected !== -1 && q.options[selected]) ? q.options[selected] : "Skipped",
            isCorrect: isCorrect,
            concept: q.concept || q.explanation || "General Concept"
        };
    });

    const prompt = `
    ${customInstruction}
    
    ROLE: Expert Educational Mentor & Analyst.
    
    CONTEXT:
    Student Class: ${data.classLevel}
    Subject: ${data.subject}
    Chapter: ${data.chapter}
    Score: ${data.score}/${data.total}

    TASK:
    Analyze the student's performance and provide a structured JSON analysis grouped by topics.
    
    DATA:
    ${JSON.stringify(attemptedQuestions, null, 2)}

    OUTPUT FORMAT (STRICT JSON ONLY, NO MARKDOWN):
    {
      "topics": [
        {
          "name": "Topic Name",
          "status": "WEAK" | "AVERAGE" | "STRONG",
          "questions": [
            {
              "text": "Question text...",
              "status": "CORRECT" | "WRONG", 
              "correctAnswer": "Option text (if wrong)"
            }
          ],
          "actionPlan": "Specific advice on how to work on this topic...",
          "studyMode": "REVISION" | "DEEP_STUDY"
        }
      ],
      "motivation": "One short punchy motivational line",
      "nextSteps": {
        "duration": "2 Days",
        "focusTopics": ["Topic A", "Topic B"],
        "action": "Brief instructions on what to study immediately."
      },
      "weakToStrongPath": [
        { "step": 1, "action": "Step-by-step action to improve weak areas..." },
        { "step": 2, "action": "..." }
      ]
    }
    
    Ensure the response is valid JSON. Do not wrap in markdown code blocks.
    `;

    return await executeWithRotation(async (key) => {
        const res = await callGeminiApi(
            [{ parts: [{ text: prompt }] }],
            modelName,
            key
        );
        return cleanJson(res.candidates?.[0]?.content?.parts?.[0]?.text || "{}");
    }, 'STUDENT');
};
