print("All builds passed!")
