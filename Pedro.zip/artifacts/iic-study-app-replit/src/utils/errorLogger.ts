import { rtdb } from '../firebase';
import { ref, push, serverTimestamp, get, remove, query, orderByChild, limitToFirst } from 'firebase/database';
import { APP_VERSION, BUILD_NUMBER } from '../constants';

export type ErrorSeverity = 'low' | 'medium' | 'high' | 'critical';

export interface AppError {
  id?: string;
  message: string;
  stack?: string;
  componentStack?: string;
  component?: string;
  type: 'react' | 'runtime' | 'promise' | 'network' | 'manual';
  severity: ErrorSeverity;
  url: string;
  userId?: string;
  userName?: string;
  userRole?: string;
  device: string;
  appVersion?: string;
  buildNumber?: string;
  browserName?: string;
  browserVersion?: string;
  osName?: string;
  osVersion?: string;
  deviceModel?: string;
  timestamp: number;
  ts?: object;
  dismissed?: boolean;
}

let _currentUserId: string | null = null;
let _currentUserName: string | null = null;
let _currentUserRole: string | null = null;

export function setErrorLoggerUser(id: string | null, name: string | null, role: string | null) {
  _currentUserId = id;
  _currentUserName = name;
  _currentUserRole = role;
}

function getDetailedDeviceInfo(): {
  device: string;
  browserName: string;
  browserVersion: string;
  osName: string;
  osVersion: string;
  deviceModel: string;
} {
  const ua = navigator.userAgent;

  // Device type
  const isMobile = /Mobi|Android/i.test(ua);
  const isTablet = /iPad|Tablet/i.test(ua);
  const device = isTablet ? 'tablet' : isMobile ? 'mobile' : 'desktop';

  // Browser
  let browserName = 'Unknown';
  let browserVersion = '';
  if (/SamsungBrowser\/(\d+)/.test(ua)) {
    browserName = 'Samsung';
    browserVersion = ua.match(/SamsungBrowser\/(\d+)/)?.[1] || '';
  } else if (/EdgA?\/(\d+)/.test(ua)) {
    browserName = 'Edge';
    browserVersion = ua.match(/EdgA?\/(\d+)/)?.[1] || '';
  } else if (/OPR\/(\d+)/.test(ua)) {
    browserName = 'Opera';
    browserVersion = ua.match(/OPR\/(\d+)/)?.[1] || '';
  } else if (/Firefox\/(\d+)/.test(ua)) {
    browserName = 'Firefox';
    browserVersion = ua.match(/Firefox\/(\d+)/)?.[1] || '';
  } else if (/Chrome\/(\d+)/.test(ua)) {
    browserName = 'Chrome';
    browserVersion = ua.match(/Chrome\/(\d+)/)?.[1] || '';
  } else if (/Safari\//.test(ua)) {
    browserName = 'Safari';
    browserVersion = ua.match(/Version\/(\d+)/)?.[1] || '';
  }

  // OS
  let osName = 'Unknown';
  let osVersion = '';
  if (/Android ([\d.]+)/.test(ua)) {
    osName = 'Android';
    osVersion = ua.match(/Android ([\d.]+)/)?.[1] || '';
  } else if (/iPhone OS ([\d_]+)/.test(ua)) {
    osName = 'iOS';
    osVersion = (ua.match(/iPhone OS ([\d_]+)/)?.[1] || '').replace(/_/g, '.');
  } else if (/iPad; CPU OS ([\d_]+)/.test(ua)) {
    osName = 'iPadOS';
    osVersion = (ua.match(/iPad; CPU OS ([\d_]+)/)?.[1] || '').replace(/_/g, '.');
  } else if (/Windows NT ([\d.]+)/.test(ua)) {
    osName = 'Windows';
    const nt = ua.match(/Windows NT ([\d.]+)/)?.[1] || '';
    osVersion = ({ '10.0': '10/11', '6.3': '8.1', '6.2': '8', '6.1': '7' } as Record<string, string>)[nt] || nt;
  } else if (/Mac OS X ([\d_]+)/.test(ua)) {
    osName = 'macOS';
    osVersion = (ua.match(/Mac OS X ([\d_]+)/)?.[1] || '').replace(/_/g, '.');
  } else if (/Linux/.test(ua)) {
    osName = 'Linux';
  }

  // Device model (Android)
  let deviceModel = '';
  if (osName === 'Android') {
    const m = ua.match(/Android [\d.]+;\s*([^;)]+?)(?:\s*Build|[;)])/);
    deviceModel = m?.[1]?.trim() || '';
  }

  return { device, browserName, browserVersion, osName, osVersion, deviceModel };
}

function classifyError(message: string): ErrorSeverity {
  const lower = message.toLowerCase();
  if (lower.includes('chunkloaderror') || lower.includes('loading chunk') || lower.includes('network error')) return 'low';
  if (lower.includes('firestore') || lower.includes('firebase') || lower.includes('permission')) return 'high';
  if (lower.includes('cannot read') || lower.includes('is not a function') || lower.includes('undefined is not')) return 'medium';
  if (lower.includes('out of memory') || lower.includes('stack overflow') || lower.includes('quota')) return 'critical';
  return 'medium';
}

const _recentErrors = new Set<string>();

/**
 * Max logs retained in Firebase. Cleanup runs after each write when
 * total exceeds this. Only medium/high/critical errors are written;
 * low-severity noise is dropped entirely.
 */
const MAX_LOG_RETENTION = 300;
const MIN_SEVERITY_TO_LOG: ErrorSeverity = 'low';
const SEVERITY_RANK: Record<ErrorSeverity, number> = {
  low: 0, medium: 1, high: 2, critical: 3,
};

/** Session-level cap: stop writing after N errors per page load to avoid floods. */
let _sessionErrorCount = 0;
const MAX_SESSION_ERRORS = 100;

const LOCAL_STORAGE_KEY = 'nst_local_error_logs';

/**
 * Retrieve locally saved errors from localStorage.
 */
export function getLocalErrors(): Array<AppError & { id: string }> {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

/**
 * Save an error locally to localStorage for instant offline/direct visibility.
 */
export function saveLocalError(err: AppError & { id: string }): void {
  try {
    const list = getLocalErrors();
    // Prepend new error
    const updated = [err, ...list.filter(item => item.id !== err.id)].slice(0, 200);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updated));
    // Dispatch event so any open ErrorNoticeBoard / AdminDashboard updates in real time
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('nsta-new-error', { detail: err }));
    }
  } catch {}
}

/**
 * Mark a local error dismissed
 */
export function markLocalErrorDismissed(id: string): void {
  try {
    const list = getLocalErrors();
    const updated = list.map(item => item.id === id ? { ...item, dismissed: true } : item);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updated));
  } catch {}
}

/**
 * Clear local error logs
 */
export function clearLocalErrors(): void {
  try {
    localStorage.removeItem(LOCAL_STORAGE_KEY);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('nsta-new-error', { detail: null }));
    }
  } catch {}
}

/**
 * Prune oldest error_logs entries so the node never exceeds MAX_LOG_RETENTION.
 * Runs fire-and-forget — never throws into the caller.
 */
async function pruneOldLogs(): Promise<void> {
  try {
    const logsRef = ref(rtdb, 'error_logs');
    const snap = await get(query(logsRef, orderByChild('timestamp'), limitToFirst(50)));
    if (!snap.exists()) return;

    const allSnap = await get(logsRef);
    if (!allSnap.exists()) return;
    const total = Object.keys(allSnap.val()).length;
    if (total <= MAX_LOG_RETENTION) return;

    const excess = total - MAX_LOG_RETENTION;
    let pruned = 0;
    snap.forEach(child => {
      if (pruned < excess) {
        remove(child.ref).catch(() => {});
        pruned++;
      }
    });
  } catch {
  }
}

export async function logErrorToFirebase(
  error: Error | string,
  opts: {
    type?: AppError['type'];
    componentStack?: string;
    severity?: ErrorSeverity;
  } = {}
): Promise<void> {
  try {
    const message = typeof error === 'string' ? error : (error?.message || String(error || 'Unknown Error'));
    const stack = typeof error === 'string' ? undefined : error?.stack;

    const lowerMsg = message.toLowerCase();
    if (
      lowerMsg.includes('could not reach cloud firestore backend') ||
      lowerMsg.includes('client will operate in offline mode') ||
      lowerMsg.includes("backend didn't respond within") ||
      lowerMsg.includes('client is offline') ||
      lowerMsg.includes('failed to get document because the client is offline')
    ) {
      return;
    }

    const severity = opts.severity ?? classifyError(message);

    if (SEVERITY_RANK[severity] < SEVERITY_RANK[MIN_SEVERITY_TO_LOG]) return;

    const dedupeKey = message.slice(0, 120);
    if (_recentErrors.has(dedupeKey)) return;
    _recentErrors.add(dedupeKey);
    setTimeout(() => _recentErrors.delete(dedupeKey), 5_000);

    if (_sessionErrorCount >= MAX_SESSION_ERRORS) return;
    _sessionErrorCount++;

    const componentMatch = opts.componentStack?.match(/\bat\s+(\w+)/);
    const component = componentMatch?.[1] || undefined;

    const { device, browserName, browserVersion, osName, osVersion, deviceModel } = getDetailedDeviceInfo();

    const errorId = `err_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

    const payload: AppError & { id: string } = {
      id: errorId,
      message: message.slice(0, 500),
      stack: stack?.slice(0, 1000),
      componentStack: opts.componentStack?.slice(0, 800),
      component,
      type: opts.type ?? 'runtime',
      severity,
      url: typeof window !== 'undefined' ? window.location.pathname : '/',
      userId: _currentUserId ?? undefined,
      userName: _currentUserName ?? undefined,
      userRole: _currentUserRole ?? undefined,
      device,
      appVersion: APP_VERSION,
      buildNumber: BUILD_NUMBER,
      browserName: browserName || undefined,
      browserVersion: browserVersion || undefined,
      osName: osName || undefined,
      osVersion: osVersion || undefined,
      deviceModel: deviceModel || undefined,
      timestamp: Date.now(),
      ts: serverTimestamp() as object,
      dismissed: false,
    };

    Object.keys(payload).forEach(k => {
      const rec = payload as unknown as Record<string, unknown>;
      if (rec[k] === undefined) delete rec[k];
    });

    // 1. ALWAYS persist locally immediately (guarantees notice board shows it even if Firebase RTDB fails)
    saveLocalError(payload);

    // 2. Push to Firebase Realtime Database
    try {
      await push(ref(rtdb, 'error_logs'), payload);
    } catch (rtdbErr) {
      console.warn('[errorLogger] RTDB push failed, kept in local storage:', rtdbErr);
    }

    if (_sessionErrorCount % 10 === 0) {
      pruneOldLogs().catch(() => {});
    }
  } catch (err) {
    console.warn('[errorLogger] Failed to log error:', err);
  }
}

/**
 * Diagnostic helper: Trigger a test error to verify Error Notice Board live
 */
export async function triggerTestError(customMsg?: string): Promise<void> {
  const testMsg = customMsg || `[Test Error] Diagnostic Check from Admin Notice Board (${new Date().toLocaleTimeString('en-IN')})`;
  await logErrorToFirebase(new Error(testMsg), {
    type: 'manual',
    severity: 'high',
  });
}

/**
 * Admin utility: manually trigger log cleanup.
 * Call from admin dashboard to keep Firebase lean.
 */
export async function cleanupErrorLogs(): Promise<{ removed: number }> {
  try {
    const logsRef = ref(rtdb, 'error_logs');
    const allSnap = await get(logsRef);
    if (!allSnap.exists()) return { removed: 0 };

    const entries = Object.entries(allSnap.val() as Record<string, AppError>);
    const total = entries.length;
    if (total <= MAX_LOG_RETENTION) return { removed: 0 };

    const sorted = entries
      .sort(([, a], [, b]) => (a.timestamp ?? 0) - (b.timestamp ?? 0))
      .slice(0, total - MAX_LOG_RETENTION);

    await Promise.all(
      sorted.map(([key]) => remove(ref(rtdb, `error_logs/${key}`)).catch(() => {}))
    );
    return { removed: sorted.length };
  } catch {
    return { removed: 0 };
  }
}
