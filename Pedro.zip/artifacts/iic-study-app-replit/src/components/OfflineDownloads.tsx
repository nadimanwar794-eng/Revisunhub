import React, { useState, useEffect } from 'react';
import { ArrowLeft, Trash2, FileText, BarChart2, CheckCircle2, FileQuestion, Download, Volume2, Square } from 'lucide-react';
import { getOfflineItems, getOfflineItemData, removeOfflineItem, OfflineItem } from '../utils/offlineStorage';
import { MarksheetCard } from './MarksheetCard';
import { User, SystemSettings } from '../types';
import { speakText, stopSpeech } from '../utils/textToSpeech';
import { renderMathInHtml, formatExplanationHtml } from '../utils/mathUtils';

interface Props {
  onBack: () => void;
  hideHeader?: boolean;
  user?: User;
  settings?: SystemSettings;
  onUpgradePlan?: () => void;
}

export const OfflineDownloads: React.FC<Props> = ({ onBack, hideHeader = false, user, settings, onUpgradePlan }) => {
  const [items, setItems] = useState<OfflineItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedItem, setSelectedItem] = useState<OfflineItem | null>(null);
  const [selectedItemData, setSelectedItemData] = useState<any>(null);
  const [loadingItemData, setLoadingItemData] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const fetchItems = async () => {
    setLoading(true);
    const data = await getOfflineItems();
    setItems(data);
    setLoading(false);
  };

  useEffect(() => {
    fetchItems();
    return () => {
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const handleSelectItem = async (item: OfflineItem) => {
    setSelectedItem(item);
    setSelectedItemData(null);
    setLoadingItemData(true);
    try {
      const data = await getOfflineItemData(item.id);
      setSelectedItemData(data);
    } catch {}
    setLoadingItemData(false);
  };

  const handleCloseViewer = () => {
    setSelectedItem(null);
    setSelectedItemData(null);
    setLoadingItemData(false);
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    setIsSpeaking(false);
  };

  const handleDelete = async (id: string) => {
    if (confirm('Are you sure you want to delete this downloaded item?')) {
      await removeOfflineItem(id);
      fetchItems();
      if (selectedItem?.id === id) {
        handleCloseViewer();
      }
    }
  };

  const toggleSpeech = (htmlContent: string) => {
    if (!window.speechSynthesis) return;
    if (isSpeaking) {
      stopSpeech();
      setIsSpeaking(false);
      return;
    }
    setIsSpeaking(true);
    speakText(htmlContent, null, 1.0, 'en-IN', undefined, () => setIsSpeaking(false)).then(utterance => {
      if (!utterance) setIsSpeaking(false);
    });
  };

  const notes = items.filter(i => i.type === 'NOTE');
  const mcqs = items.filter(i => i.type === 'MCQ');
  const analysis = items.filter(i => i.type === 'ANALYSIS');

  const renderItemViewer = (item: OfflineItem) => {
    if (loadingItemData) {
      return (
        <div className="fixed inset-0 z-[9999] bg-white flex flex-col h-screen w-screen overflow-hidden">
          <div className="flex items-center gap-2 px-3 py-2 border-b bg-slate-50 sticky top-0 z-10">
            <button onClick={handleCloseViewer} className="p-1.5 bg-slate-200 rounded-full text-slate-700 hover:bg-slate-300">
              <ArrowLeft size={16} />
            </button>
            <div>
              <h2 className="text-sm font-bold text-slate-800 line-clamp-1 leading-tight">{item.title}</h2>
              <p className="text-[10px] text-slate-500 leading-tight">{item.subtitle}</p>
            </div>
          </div>
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <div className="text-3xl mb-3 animate-pulse">📖</div>
              <p className="text-sm font-bold text-slate-500">Loading notes…</p>
            </div>
          </div>
        </div>
      );
    }

    const data = selectedItemData;

    if (item.type === 'ANALYSIS' && data?.result && user) {
      return (
        <MarksheetCard
          result={data.result}
          questions={data.questions}
          user={user}
          settings={settings}
          onClose={handleCloseViewer}
        />
      );
    }

    return (
      <div className="fixed inset-0 z-[9999] bg-white flex flex-col h-screen w-screen overflow-hidden">
        <div className="flex items-center justify-between px-3 py-1.5 border-b bg-slate-50 sticky top-0 z-10">
          <div className="flex items-center gap-2">
            <button onClick={handleCloseViewer} className="p-1.5 bg-slate-200 rounded-full text-slate-700 hover:bg-slate-300">
              <ArrowLeft size={16} />
            </button>
            <div>
              <h2 className="text-sm font-bold text-slate-800 line-clamp-1 leading-tight">{item.title}</h2>
              <p className="text-[10px] text-slate-500 leading-tight">{item.subtitle}</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            {item.type === 'NOTE' && data?.html && (
              <button
                onClick={() => toggleSpeech(data.html)}
                className={`p-1.5 rounded-full ${isSpeaking ? 'bg-indigo-100 text-indigo-600' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
                title={isSpeaking ? 'Stop Reading' : 'Read Aloud'}
              >
                {isSpeaking ? <Square size={16} /> : <Volume2 size={16} />}
              </button>
            )}
            <button onClick={() => handleDelete(item.id)} className="p-1.5 text-red-500 bg-red-50 rounded-full hover:bg-red-100">
              <Trash2 size={16} />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 bg-white">
          {!data ? (
            <div className="text-center py-20 text-slate-400">
              <p className="text-3xl mb-3">📭</p>
              <p className="font-bold text-slate-600">Content not available</p>
              <p className="text-xs mt-1">This saved item may be corrupted. Try saving it again.</p>
            </div>
          ) : item.type === 'NOTE' && (data.html || data.chunkNotes || data.content) ? (
            data.html ? (
              <div className="prose prose-slate max-w-none" dangerouslySetInnerHTML={{ __html: renderMathInHtml(data.html) }} />
            ) : (
              <div className="whitespace-pre-wrap text-sm text-slate-700 leading-relaxed font-medium">
                {data.chunkNotes || data.content || ''}
              </div>
            )
          ) : item.type === 'MCQ' ? (
            <div className="space-y-6">
              {(() => {
                const questions = Array.isArray(data) ? data : (data.questions || []);
                const theory = data.theory;
                const topicNotes = data.topicNotes;
                return (
                  <>
                    {theory && (
                      <div className="mb-8 p-6 bg-slate-50 rounded-2xl border border-slate-200">
                        <h3 className="text-lg font-black text-slate-800 mb-4 border-b border-slate-200 pb-2">Chapter Theory</h3>
                        <div className="prose prose-slate max-w-none text-sm" dangerouslySetInnerHTML={{ __html: renderMathInHtml(theory.replace(/\n/g, '<br/>')) }} />
                      </div>
                    )}
                    {topicNotes && topicNotes.length > 0 && (
                      <div className="mb-8 space-y-4">
                        <h3 className="text-lg font-black text-slate-800 mb-4 border-b border-slate-200 pb-2">Topic Notes</h3>
                        {topicNotes.map((note: any, idx: number) => (
                          <div key={idx} className="p-6 bg-slate-50 rounded-2xl border border-slate-200">
                            <h4 className="font-bold text-slate-700 mb-2">{note.title || note.topic}</h4>
                            <div className="prose prose-slate max-w-none text-sm" dangerouslySetInnerHTML={{ __html: renderMathInHtml(note.content) }} />
                          </div>
                        ))}
                      </div>
                    )}
                    {questions.length > 0 && <h3 className="text-lg font-black text-slate-800 mb-4 border-b border-slate-200 pb-2 mt-8">Practice Questions</h3>}
                    {questions.map((q: any, idx: number) => (
                      <div key={idx} className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                        <p className="font-bold text-slate-800 mb-3">{idx + 1}. <span dangerouslySetInnerHTML={{ __html: renderMathInHtml(q.question) }} /></p>
                        <div className="space-y-2">
                          {q.options?.map((opt: string, oIdx: number) => (
                            <div key={oIdx} className={`p-3 rounded-lg border flex items-center ${oIdx === q.correctAnswer ? 'bg-green-50 border-green-200 text-green-800 font-bold' : 'bg-white border-slate-200 text-slate-600'}`}>
                              {oIdx === q.correctAnswer && <CheckCircle2 size={16} className="mr-2 text-green-600 flex-shrink-0" />}
                              <span dangerouslySetInnerHTML={{ __html: renderMathInHtml(opt) }} />
                            </div>
                          ))}
                        </div>
                        {q.explanation && (
                          <div className="mt-4 p-3 bg-blue-50 text-blue-800 rounded-lg text-sm border border-blue-100">
                            <strong>Explanation:</strong> <span dangerouslySetInnerHTML={{ __html: formatExplanationHtml(q.explanation) }} />
                          </div>
                        )}
                      </div>
                    ))}
                  </>
                );
              })()}
            </div>
          ) : item.type === 'ANALYSIS' && data?.result ? (
            <div className="space-y-6 w-full mx-auto">
              <div className="bg-gradient-to-br from-indigo-500 to-purple-600 p-6 rounded-2xl text-white text-center shadow-lg">
                <h3 className="text-xl font-black mb-2">{data.result.chapterTitle}</h3>
                <div className="text-5xl font-black mb-2">{data.result.score} <span className="text-2xl opacity-70">/ {data.result.totalQuestions}</span></div>
                <p className="font-bold opacity-90">Total Time: {Math.floor((data.result.timeTaken || 0) / 60)}m {(data.result.timeTaken || 0) % 60}s</p>
              </div>
              <h4 className="font-bold text-slate-800 text-lg border-b pb-2">Questions Review</h4>
              <div className="space-y-4">
                {data.questions?.map((q: any, idx: number) => {
                  const userAnswer = data.result.answers[idx];
                  const isCorrect = userAnswer === q.correctAnswer;
                  const isSkipped = userAnswer === undefined || userAnswer === null || userAnswer === -1;
                  return (
                    <div key={idx} className={`p-4 rounded-xl border ${isCorrect ? 'border-green-200 bg-green-50' : isSkipped ? 'border-slate-200 bg-slate-50' : 'border-red-200 bg-red-50'}`}>
                      <div className="flex justify-between items-start mb-2 gap-4">
                        <p className="font-bold text-slate-800 flex-1">{idx + 1}. <span dangerouslySetInnerHTML={{ __html: renderMathInHtml(q.question) }} /></p>
                        <span className={`text-xs font-black px-2 py-1 rounded-full whitespace-nowrap ${isCorrect ? 'bg-green-100 text-green-700' : isSkipped ? 'bg-slate-200 text-slate-700' : 'bg-red-100 text-red-700'}`}>
                          {isCorrect ? 'Correct' : isSkipped ? 'Skipped' : 'Wrong'}
                        </span>
                      </div>
                      <div className="space-y-1 mt-3">
                        {q.options?.map((opt: string, oIdx: number) => {
                          const isSelected = userAnswer === oIdx;
                          const isActuallyCorrect = q.correctAnswer === oIdx;
                          let bgClass = 'bg-white border-slate-200 text-slate-600';
                          if (isActuallyCorrect) bgClass = 'bg-green-100 border-green-300 text-green-800 font-bold';
                          else if (isSelected && !isActuallyCorrect) bgClass = 'bg-red-100 border-red-300 text-red-800';
                          return (
                            <div key={oIdx} className={`p-2 rounded-lg border text-sm flex items-center ${bgClass}`}>
                              {isActuallyCorrect && <CheckCircle2 size={14} className="mr-2 flex-shrink-0" />}
                              <span dangerouslySetInnerHTML={{ __html: renderMathInHtml(opt) }} />
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="text-center py-20 text-slate-400">
              <p className="text-3xl mb-3">📄</p>
              <p className="font-bold text-slate-600">Preview not available for this item type</p>
            </div>
          )}
        </div>
      </div>
    );
  };

  const renderList = (title: string, list: OfflineItem[], icon: React.ReactNode) => {
    if (list.length === 0) return null;
    return (
      <div className="mb-8">
        <h3 className="text-lg font-black text-slate-800 flex items-center gap-2 mb-4 border-b border-slate-200 pb-2">
          {icon} {title}
        </h3>
        <div className="space-y-3">
          {list.map(item => (
            <div
              key={item.id}
              className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => handleSelectItem(item)}
            >
              <div>
                <h4 className="font-bold text-slate-800 line-clamp-1">{item.title}</h4>
                <p className="text-xs text-slate-600 mt-1">{item.subtitle} • {new Date(item.timestamp).toLocaleDateString()}</p>
              </div>
              <button onClick={(e) => { e.stopPropagation(); handleDelete(item.id); }} className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-full transition-colors">
                <Trash2 size={18} />
              </button>
            </div>
          ))}
        </div>
      </div>
    );
  };

  if (selectedItem) {
    return renderItemViewer(selectedItem);
  }

  const isSubscriber = (user?.subscriptionLevel === 'BASIC' || user?.subscriptionLevel === 'ULTRA' || user?.isPremium || user?.role === 'ADMIN');

  if (!isSubscriber) {
    return (
      <div className={`bg-slate-50 ${hideHeader ? 'pb-8' : 'min-h-screen pb-8'}`}>
        {!hideHeader && (
          <div className="bg-white p-4 border-b border-slate-200 flex items-center justify-between sticky top-0 z-40">
            <div className="flex items-center gap-3">
              <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                <ArrowLeft size={20} className="text-slate-600" />
              </button>
              <h1 className="text-xl font-black text-slate-800">Offline Downloads</h1>
            </div>
            <span className="text-[10px] font-black uppercase tracking-wider px-2 py-1 rounded bg-amber-50 text-amber-700 border border-amber-200 flex items-center gap-1">
              🔒 Basic+
            </span>
          </div>
        )}
        <div className="max-w-md mx-auto p-5 mt-4">
          <div className="bg-gradient-to-b from-[#18182e] via-[#121224] to-[#0a0a14] rounded-3xl p-6 text-center border border-purple-500/30 shadow-2xl relative overflow-hidden text-white">
            <div className="absolute top-0 right-0 w-44 h-44 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-44 h-44 bg-pink-600/10 rounded-full blur-3xl pointer-events-none" />

            <div className="w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center text-3xl bg-gradient-to-br from-amber-400/20 to-purple-600/20 border border-amber-400/40 shadow-inner">
              👑
            </div>

            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-black tracking-wider uppercase mb-3 bg-amber-400/15 text-amber-300 border border-amber-400/30">
              <span>Basic & Ultra Tier Required</span>
            </div>

            <h3 className="text-xl font-black text-white mb-2 tracking-tight">
              Offline Downloads Locked
            </h3>

            <p className="text-xs text-slate-300 leading-relaxed mb-5">
              Notes aur MCQs ko offline download karke bina internet ke padhne ka feature sirf <strong className="text-blue-400 font-bold">Basic</strong> aur <strong className="text-purple-400 font-bold">Ultra</strong> plan members ke liye available hai.
            </p>

            <div className="grid grid-cols-2 gap-2.5 mb-6 text-left">
              <div className="p-3 rounded-2xl bg-white/5 border border-blue-400/30">
                <p className="text-xs font-black text-blue-400 mb-1 flex items-center gap-1">⭐ Basic Plan</p>
                <p className="text-[11px] text-slate-300">Offline notes & questions downloads available</p>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-purple-400/30">
                <p className="text-xs font-black text-purple-400 mb-1 flex items-center gap-1">👑 Ultra Plan</p>
                <p className="text-[11px] text-slate-300">All offline downloads + Ultra notes & priority chat</p>
              </div>
            </div>

            <div className="flex flex-col gap-2.5">
              <button
                type="button"
                onClick={onUpgradePlan ? onUpgradePlan : onBack}
                className="w-full py-3.5 rounded-2xl font-black text-xs uppercase tracking-wider text-white shadow-xl cursor-pointer active:scale-95 transition-all bg-gradient-to-r from-amber-500 via-pink-600 to-purple-600 hover:opacity-95"
              >
                ⚡ Upgrade to Basic / Ultra
              </button>
              <button
                type="button"
                onClick={onBack}
                className="w-full py-2.5 rounded-xl font-semibold text-xs text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 transition-colors"
              >
                Dashboard Par Wapas Jayein
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-slate-50 ${hideHeader ? 'pb-8' : 'min-h-screen pb-8'}`}>
      {!hideHeader && (
        <div className="bg-white p-4 border-b border-slate-200 flex items-center gap-3 sticky top-0 z-40">
          <h1 className="text-xl font-black text-slate-800 px-2">Offline Downloads</h1>
        </div>
      )}
      <div className={`${hideHeader ? 'p-0' : 'p-4'} max-w-4xl mx-auto`}>
        {loading ? (
          <div className="flex justify-center py-10"><span className="animate-spin text-2xl">⏳</span></div>
        ) : items.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-3xl border border-slate-200 shadow-sm">
            <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-500">
              <Download size={32} />
            </div>
            <h3 className="text-xl font-bold text-slate-700 mb-2">No Downloads Yet</h3>
            <p className="text-slate-600 max-w-xs mx-auto">Items you save offline will appear here so you can access them without internet.</p>
          </div>
        ) : (
          <>
            {renderList('Saved Notes', notes, <FileText size={20} className="text-blue-500" />)}
            {renderList('Saved MCQs', mcqs, <FileQuestion size={20} className="text-purple-500" />)}
            {renderList('Analysis Reports', analysis, <BarChart2 size={20} className="text-indigo-500" />)}
          </>
        )}
      </div>
    </div>
  );
};
